#!/bin/bash

if [ ! -f [PATH]/monitoring_output.txt ]; then
	pactl load-module module-loopback latency_msec=1 >> [PATH]/monitoring_output.txt
	exit
else
	file=[PATH]/monitoring_output.txt

	while IFS= read session_number;do
		pactl unload-module $session_number
		rm [PATH]/monitoring_output.txt
		
	done < "$file"
	exit
fi 
