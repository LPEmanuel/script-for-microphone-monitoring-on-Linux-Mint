#!/bin/bash
rm [PATH]/monitoring_output.txt
exit
